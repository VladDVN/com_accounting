DROP TABLE IF EXISTS `#__acc_cities`;

DROP TABLE IF EXISTS `#__acc_countries`;

DROP TABLE IF EXISTS `#__acc_currencies`;

DROP TABLE IF EXISTS `#__acc_kinds`;

DROP TABLE IF EXISTS `#__acc_schema`;

DROP TABLE IF EXISTS `#__acc_taxes`;

DROP TABLE IF EXISTS `#__acc_lots`;

DROP TABLE IF EXISTS `#__acc_clients`;

DROP TABLE IF EXISTS `#__acc_contracts`;

DROP TABLE IF EXISTS `#__acc_firms`;

DROP TABLE IF EXISTS `#__acc_goods`;

DROP TABLE IF EXISTS `#__acc_goods_periodic`;

DROP TABLE IF EXISTS `#__acc_receipt`;

DROP TABLE IF EXISTS `#__acc_receipt_rows`;

DROP TABLE IF EXISTS `#__acc_unitsmeasuring`;

DROP TABLE IF EXISTS `#__acc_warehouses`;
