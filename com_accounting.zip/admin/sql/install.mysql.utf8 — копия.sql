DROP TABLE IF EXISTS `#__acc_schema`;

DROP TABLE IF EXISTS `#__acc_taxes`;

DROP TABLE IF EXISTS `#__acc_lots`;

DROP TABLE IF EXISTS `#__acc_clients`;

DROP TABLE IF EXISTS `#__acc_contracts`;

DROP TABLE IF EXISTS `#__acc_firms`;

DROP TABLE IF EXISTS `#__acc_goods`;

DROP TABLE IF EXISTS `#__acc_goods_periodic`;

DROP TABLE IF EXISTS `#__acc_receipt`;

DROP TABLE IF EXISTS `#__acc_receipt_rows`;

CREATE TABLE `#__acc_schema` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `table` varchar(50) DEFAULT NULL,
  `rows_table` varchar(50) DEFAULT NULL,
  `form_name` varchar(50) DEFAULT NULL,
  `struct_table` varchar(50) DEFAULT NULL,
  `owner_table` varchar(50) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `ismark` int(11) DEFAULT NULL,
  `localization` varchar(50) DEFAULT NULL,
  `catid` bigint(20) NOT NULL COMMENT 'Category ID',
  `state` tinyint(3) NOT NULL DEFAULT 1 COMMENT 'Publish status'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO #__acc_schema (id,name,`table`,rows_table,form_name,struct_table,owner_table,sort_order,ismark,localization,catid,state) VALUES
	 (1,'FirmsClients','acc_firmsclients','','','acc_firmclient_struct_table','',1,0,'COM_ACCOUNTING_FIRMSCLIENTS',14,1),
	 (2,'Contracts','acc_contracts','','','acc_contract_struct_table','acc_clients',2,0,'COM_ACCOUNTING_CONTRACTS',14,1),
	 (3,'Goods','acc_goods','','good_details.xml','acc_goods_struct_table','acc_',3,0,'COM_ACCOUNTING_GOODS',14,1),
	 (4,'Analogues','acc_analogues','','','acc_analogues_struct_table','',4,0,'COM_ACCOUNTING_ANALOGUES',14,1),
	 (5,'Clients','acc_clients','','client_details.xml','acc_clients_struct_table','',5,0,'COM_ACCOUNTING_CLIENTS',14,1),
	 (6,'Individuals','acc_individuals','','','acc_individual_struct_table','',6,0,'COM_ACCOUNTING_INDIVIDUALS',14,1),
	 (7,'Banks','acc_banks','','','acc_bank_struct_table','',7,0,'COM_ACCOUNTING_BANKS',14,1),
	 (8,'ForeignerBanks','acc_foreignerbanks','','','acc_foreignerbank_struct_table','',8,0,'COM_ACCOUNTING_FOREIGNERBANKS',14,1),
	 (9,'BankAccounts','acc_bankaccounts','','','acc_bankaccount_struct_table','',9,0,'COM_ACCOUNTING_BANKACCOUNTS',14,1),
	 (10,'Currency','acc_currency','','','acc_currency_struct_table','',10,0,'COM_ACCOUNTING_CURRENCY',14,1);
INSERT INTO #__acc_schema (id,name,`table`,rows_table,form_name,struct_table,owner_table,sort_order,ismark,localization,catid,state) VALUES
	 (11,'KindProperties','acc_kindproperties','','','acc_kindproperties_struct_table','',11,0,'COM_ACCOUNTING_KINDPROPERTIES',14,1),
	 (12,'CargoDeclaration','acc_ccd','','','acc_ccd_struct_table','',12,0,'COM_ACCOUNTING_CARGODECLARATION',15,1),
	 (13,'CashFlow','acc_cashflow','','','acc_cashflow_struct_table','',13,0,'COM_ACCOUNTING_CASHFLOW',14,1),
	 (14,'_RegistersMovement','acc_registersmovements','','','acc_registersmovement_struct_table','',14,0,'COM_ACCOUNTING_REGISTERS_MOVEMENTS',0,1),
	 (15,'_UnitsMeasuring','acc_unitsmeasuring','','','acc_unitsmeasuring_struct_table','',15,0,'COM_ACCOUNTING_UNITS_MEASURING',14,1),
	 (16,'_ValuesProperties','acc_valuesproperties','','','acc_valueproperty_struct_table','',16,0,'COM_ACCOUNTING_VALUE_PROPERTY',14,1),
	 (17,'CashBoxes','acc_cashboxes','','','acc_cashbox_struct_table','',17,0,'COM_ACCOUNTING_CASHBOXES',14,1),
	 (19,'Completions','acc_completions','','','acc_completion_struct_table','',19,0,'COM_ACCOUNTING_COMPLECTIONS',14,1),
	 (21,'Countries','acc_countries','','','acc_classificatorcountries_struct_table','',21,0,'COM_ACCOUNTING_COUNTRIES',14,1),
	 (22,'Lots','acc_lots','','','acc_lot_struct_table','',22,0,'COM_ACCOUNTING_LOTS',14,1);
INSERT INTO #__acc_schema (id,name,`table`,rows_table,form_name,struct_table,owner_table,sort_order,ismark,localization,catid,state) VALUES
	 (23,'_Sites','acc_sites','','','acc_site_struct_table','',23,0,'COM_ACCOUNTING_SITES',14,1),
	 (24,'_OwnFirms','acc_ownfirms','','','acc_ownfirm_struct_table','',24,0,'COM_ACCOUNTING_OWNFIRMS',14,1),
	 (25,'_ClientProperties','acc_clientproperty','','','acc_clientproperty_struct_table','',25,0,'COM_ACCOUNTING_CLIENT_PROPERTY',14,1),
	 (26,'_ProductProperties','acc_productproperty','','','acc_productproperty_struct_table','',26,0,'COM_ACCOUNTING_PRODUCT_PROPERTY',14,1),
	 (27,'_Discounts','acc_discounts','','','acc_discount_struct_table','',27,0,'COM_ACCOUNTING_DISCOUNTS',14,1),
	 (28,'_Houses','acc_houses','','','acc_house_struct_table','',28,0,'COM_ACCOUNTING_HOUSES',14,1),
	 (29,'_SalesTaxRates','acc_salestaxrates','','','acc_salestaxrates_struct_table','',29,0,'COM_ACCOUNTING_SALES_TAX_RATES',14,1),
	 (30,'_PricesTypes','acc_pricestypes','','','acc_pricestypes_struct_table','',30,0,'COM_ACCOUNTING_PRICES_TYPES',14,1),
	 (31,'_AccountingAnalist','acc_accouninganalist','','','acc_accountinganalist_struct_table','',31,0,'Аналітика управлінського обліку (субконто)',14,1),
	 (32,'_Firms','acc_firms','acc_firms_content','','acc_firm_struct_table','',32,0,'COM_ACCOUNTING_FIRMS',14,1);
INSERT INTO #__acc_schema (id,name,`table`,rows_table,form_name,struct_table,owner_table,sort_order,ismark,localization,catid,state) VALUES
	 (33,'_Prices','acc_prices','','','acc_price_struct_table','',33,0,'COM_ACCOUNTING_PRICES',14,1),
	 (34,'_Users','salto_users','','','acc_users_struct_table','',34,0,'Користувачі',14,1),
	 (50,'Receipt','acc_receipt','','receipt_details.xml','acc_receipt_struct_table','',1,0,'COM_ACCOUNTING_DOCUMENT_PURCHASE_INVOICE',15,1),
	 (51,'Clients8','Reference19','Reference19_VT12191','','','',14,0,'Контрагенти 8-ки',14,1);

CREATE TABLE `#__acc_taxes` (
  `id` int(11) unsigned DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `rate` decimal(6,2) DEFAULT NULL,
  `catid` bigint(20) DEFAULT NULL,
  `state` tinyint(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `#__acc_lots` (
  `id` int(11) unsigned DEFAULT NULL,
  `parent_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `isfolder` tinyint(1) DEFAULT NULL,
  `ismark` tinyint(1) DEFAULT NULL,
  `catid` bigint(20) DEFAULT NULL,
  `state` tinyint(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `#__acc_clients` (
  `id` int(11) unsigned DEFAULT NULL,
  `parent_id` int(11) unsigned DEFAULT NULL,
  `owner_id` int(11) unsigned DEFAULT NULL,
  `code` int(11) unsigned DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `isfolder` tinyint(1) DEFAULT NULL,
  `ismark` tinyint(1) DEFAULT NULL,
  `catid` bigint(20) DEFAULT NULL,
  `state` tinyint(3) DEFAULT NULL,
  `fullname` varchar(200) DEFAULT NULL,
  `identificator` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `country` int(11) unsigned DEFAULT NULL,
  `city` int(11) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `#__acc_contracts` (
  `id` int(11) unsigned DEFAULT NULL,
  `owner_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `currency` int(11) unsigned DEFAULT NULL,
  `kind_costs` varchar(50) DEFAULT NULL,
  `discount` varchar(50) DEFAULT NULL,
  `depth_credit` varchar(50) DEFAULT NULL,
  `amount_credit` varchar(50) DEFAULT NULL,
  `control_credit` varchar(50) DEFAULT NULL,
  `fix_rate_debt` varchar(50) DEFAULT NULL,
  `tax` int(11) unsigned DEFAULT NULL,
  `catid` bigint(20) DEFAULT NULL,
  `state` tinyint(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `#__acc_firms` (
  `id` int(11) unsigned DEFAULT NULL,
  `parent_id` int(11) unsigned DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `fullname` varchar(150) DEFAULT NULL,
  `basebankaccount` int(11) unsigned DEFAULT NULL,
  `identificator` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `catid` bigint(20) DEFAULT NULL,
  `state` tinyint(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `#__acc_goods` (
  `id` int(11) unsigned DEFAULT NULL,
  `parent_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `fullname` varchar(150) DEFAULT NULL,
  `article` varchar(11) DEFAULT NULL,
  `baseunit` int(11) unsigned DEFAULT NULL,
  `isweight` tinyint(1) DEFAULT NULL,
  `kind` int(11) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `inprice` varchar(50) DEFAULT NULL,
  `num_gtd` varchar(50) DEFAULT NULL,
  `primaryunit` int(11) unsigned DEFAULT NULL,
  `property` int(11) unsigned DEFAULT NULL,
  `tax` varchar(50) DEFAULT NULL,
  `tax_trade` varchar(50) DEFAULT NULL,
  `country` int(11) unsigned DEFAULT NULL,
  `code` int(11) unsigned DEFAULT NULL,
  `isfolder` tinyint(1) DEFAULT NULL,
  `ismark` tinyint(1) DEFAULT NULL,
  `catid` bigint(20) DEFAULT NULL,
  `state` tinyint(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `#__acc_goods_periodic` (
  `id` int(11) unsigned DEFAULT NULL,
  `column` varchar(50) DEFAULT NULL,
  `catid` bigint(20) unsigned DEFAULT NULL,
  `value` varchar(70) DEFAULT NULL COMMENT 'id or number or string',
  `data` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `#__acc_receipt` (
  `id` int(11) unsigned DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `code` varchar(20) DEFAULT NULL,
  `ownfirm` int(11) unsigned DEFAULT NULL,
  `client` int(11) DEFAULT NULL,
  `contract` int(11) DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `comment` varchar(150) DEFAULT NULL,
  `considerVAT` int(11) DEFAULT NULL,
  `amount_incl_VAT` int(11) DEFAULT NULL,
  `considerST` int(11) DEFAULT NULL,
  `amount_incl_ST` int(11) DEFAULT NULL,
  `pricestypes` int(11) DEFAULT NULL,
  `amountmutual` decimal(20,2) DEFAULT NULL,
  `rateVAT` int(11) DEFAULT NULL,
  `doc_number_in` varchar(50) DEFAULT NULL,
  `doc_date_in` date DEFAULT NULL,
  `paymentday` date DEFAULT NULL,
  `doc_reason` text DEFAULT NULL COMMENT 'JSON',
  `catid` bigint(20) DEFAULT NULL,
  `state` tinyint(3) DEFAULT NULL,
  `author` int(11) unsigned DEFAULT NULL,
  `isheld` tinyint(1) DEFAULT NULL,
  `ismark` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modifyed` datetime DEFAULT NULL,
  `meta_id` int(11) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `#__acc_receipt_rows` (
  `parent_id` int(11) unsigned DEFAULT NULL,
  `num_line` int(11) unsigned DEFAULT NULL,
  `warehouse` int(11) DEFAULT NULL,
  `kindgood` int(11) DEFAULT NULL,
  `good` int(11) DEFAULT NULL,
  `quantity` decimal(25,7) DEFAULT NULL,
  `unit` int(11) unsigned DEFAULT NULL,
  `price` decimal(25,7) DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT NULL,
  `amountVAT` decimal(20,2) DEFAULT NULL,
  `amountST` decimal(20,2) DEFAULT NULL,
  `tax` int(11) unsigned DEFAULT NULL,
  `catid` bigint(20) DEFAULT NULL,
  `state` tinyint(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;